Answers
==========================

This library/project seeks to simplfy the installation of unix applications which typically require a list of questions to be answered or commands to be run. The idea is to provide a simple library which can run a script file against an executable, automating the entire process. 

When combined with a configuration management tool, such as Puppet or Chef, this library should be very powerful. 